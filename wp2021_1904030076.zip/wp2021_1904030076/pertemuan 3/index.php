<!DOCTYPE html>
<html lang="en">
<head>
<title>pertemuan 3</title>
</head>
<body>
    <!-- PHP dalam HTML -->
    <h1>selamat datang, <?php echo "Muhamad Raihan Firdaus"; ?></h1>

    <!-- tag HTML dalam PHP -->
    <?php echo "<h1>di Pembelajaran Web Programing</h2>";?>
<hr>
        <h2>tipe data integer</h2>

        <?php
echo "Desimal : "; var_dump(1966); echo "<br>";
echo "octa : "  ; var_dump(01234); echo "<br>";
echo "Hexadecimal : "  ; var_dump(0x1a); echo "<br>";
echo "binary : "  ; var_dump(0111111); echo "<br>";
echo "underscore di nomor : "  ; var_dump(1505000); echo "<br>";

        ?>

        <hr>
        <h2>variable</h2>
        <?php
$namadepan = "Muhamad Raihan";
$namablk = "Firdaus";
$mk = "Web Programing";
$hobi = " Badminton & Futsal";
        ?>

        <h4>identitas diri</h4>
        <p>nama : <?php echo $namadepan ." ". $namablk; ?></p>
        <p>Mata kuliah : <?php echo $mk; ?></p>
        <p>hobi : <?php echo$hobi; ?></p>
</body>
</html>
    